#ifndef BG
#define BG
#endif
