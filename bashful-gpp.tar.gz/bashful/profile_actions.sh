#include "actions.sh"
#ifndef PROFILE_ACTIONS
#define PROFILE_ACTIONS
profile_actions() #{{{1
{
    # <doc:profile_actions> {{{
    #
    # Lists all available profile actions.
    #
    # </doc:profile_actions> }}}

    actions "profile"
}
#endif
